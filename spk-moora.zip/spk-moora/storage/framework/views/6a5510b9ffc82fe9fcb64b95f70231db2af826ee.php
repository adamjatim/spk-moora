<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <!-- Styles -->
    <?php echo \Livewire\Livewire::styles(); ?>

    <style></style>
</head>

<body class="">
    <div class="min-h-screen bg-gray-100">
        <h1 class="text-center font-bold" style="font-size: 1.25rem; font-weight:1.5rem"><?php echo e($title); ?>

        </h1>
        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="flex flex-row gap-4">
                    <!-- Total Calon Pegawai -->
                    <div id="total-pegawai" class="mt-4 text-5xl">
                      Total Data Calon Pegawai : <?php echo e($totals['totalPegawai']); ?>

                    </div>

                    <!-- Total Layak -->
                    <div id="total-layak" class="mt-4 text-5xl">
                      Total Data Calon Pegawai Layak : <?php echo e($totals['totalLayak']); ?>

                    </div>

                    <!-- Total Tidak Layak -->
                    <div id="total-tidak-layak" class="mt-4 text-5xl">
                      Total Data Calon Pegawai Tidak Layak : <?php echo e($totals['totalTidakLayak']); ?>

                    </div>
                </div>

                <!-- Tabel Nilai Seleksi -->
                <table style="width: 100%; border-collapse: collapse; border: 1px solid #ddd; margin-top: 2rem;">
                    <thead>
                        <tr>
                            <th style="padding: 8px; border: 1px solid #ddd;">Ranking</th>
                            <th style="padding: 8px; border: 1px solid #ddd;">Nama Calon Pegawai</th>
                            <th style="padding: 8px; border: 1px solid #ddd;">Nilai Hasil Sistem</th>
                            <th style="padding: 8px; border: 1px solid #ddd;">Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dataHasils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="padding: 8px; border: 1px solid #ddd;"><?php echo e($nilai['id']); ?></td>
                                <td style="padding: 8px; border: 1px solid #ddd;"><?php echo e($nilai['nama_calon']); ?></td>
                                <td style="padding: 8px; border: 1px solid #ddd;"><?php echo e($nilai['nilai_yi']); ?></td>
                                <td style="padding: 8px; border: 1px solid #ddd;"><?php echo e($nilai['keterangan']); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH /opt/lampp/htdocs/spk-moora/resources/views/pdf/document.blade.php ENDPATH**/ ?>