<?php $__env->startPush('modal'); ?>
    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
            <span class="block sm:inline"><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
            <span class="block sm:inline"><?php echo e(session('error')); ?></span>
        </div>
    <?php endif; ?>

    <?php if(session()->has('message')): ?>
        <div id="toast" class="fixed top-0 right-0 flex m-5 transition ease-in-out delay-300 duration-300 cursor-default">
            <div class="text-green-800 bg-green-50 rounded-lg shadow-lg w-96">
                <div class="px-6 py-4 flex flex-row justify-between items-center">
                    <div class="flex flex-col">
                        <p class="mt-2 text-md "><?php echo e(session('message')); ?></p>
                        <?php if(session()->has('filterSuccess')): ?>
                            <a href="<?php echo e(route('penilaian.index')); ?>"
                                class="flex flex-row mt-2 gap-3 cursor-pointer text-md bg-green-600 hover:bg-green-700 text-gray-100 px-4 py-2 items-center rounded-md">
                                <?php echo e(session('filterSuccess')); ?>

                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 15 15">
                                    <path fill="currentColor"
                                        d="M8.293 2.293a1 1 0 0 1 1.414 0l4.5 4.5a1 1 0 0 1 0 1.414l-4.5 4.5a1 1 0 0 1-1.414-1.414L11 8.5H1.5a1 1 0 0 1 0-2H11L8.293 3.707a1 1 0 0 1 0-1.414" />
                                </svg>
                            </a>
                        <?php endif; ?>
                    </div>
                    <button id="closeToast">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-gray-500" fill="none"
                            viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>
                <div id="animatedDiv" class="h-1 bg-green-300 rounded-lg"></div>
            </div>

            <script>
                const animatedDiv = document.getElementById("animatedDiv");
                let currentWidth = 100; // Start at 100%

                // Gradually decrease the width of the progress bar
                const interval = setInterval(() => {
                    currentWidth -= 1; // Decrease width by 1% per step
                    animatedDiv.style.width = currentWidth + "%";

                    if (currentWidth <= 0) {
                        clearInterval(interval); // Stop the interval when width reaches 0%
                        removeToast(); // Remove the toast once animation is complete
                    }
                }, 40); // 40ms per step for 4000ms total (100 steps)

                // Close the toast on button click
                const removeToastButton = document.getElementById('closeToast');
                removeToastButton.addEventListener('click', () => {
                    clearInterval(interval); // Stop the width animation
                    removeToast();
                });

                // Function to remove the toast
                function removeToast() {
                    const toast = document.getElementById('toast');
                    if (toast) {
                        toast.remove();
                    }
                }

                // Auto-remove the toast after 4 seconds if not closed manually
                setTimeout(() => {
                    removeToast();
                }, 4000);
            </script>
        </div>
    <?php endif; ?>

    <!-- Modal Konfirmasi Hapus -->
    <div>
        <!-- Modal Konfirmasi Penghapusan -->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'jetstream::components.modal','data' => ['wire:model' => 'confirmingDelete']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'confirmingDelete']); ?>
            <div class="px-6 py-4">
                <h2 class="text-lg font-semibold text-gray-900">Konfirmasi Penghapusan</h2>
                <p class="mt-2 text-sm text-gray-600">Apakah Anda yakin ingin menghapus data ini? Tindakan ini
                    tidak dapat dibatalkan.</p>
                <p class="mt-2 text-sm text-gray-600">Nama: <strong><?php echo e($dataToDelete['nama'] ?? ''); ?></strong>
                </p>
            </div>

            <div class="flex justify-end px-6 py-3 bg-gray-50">
                <button wire:click="deleteData(<?php echo e($dataToDelete['id'] ?? ''); ?>)"
                    class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-500">
                    Hapus
                </button>
                <button wire:click="$set('confirmingDelete', false)"
                    class="ml-2 bg-gray-200 text-gray-800 px-4 py-2 rounded-md hover:bg-gray-300">
                    Batal
                </button>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>
<?php $__env->stopPush(); ?>
<?php /**PATH /opt/lampp/htdocs/spk-moora/resources/views/livewire/calon-pegawai/partials/modal.blade.php ENDPATH**/ ?>