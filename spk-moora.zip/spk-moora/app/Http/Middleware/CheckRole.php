<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CheckRole
{
  /**
   * Handle an incoming request.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
   * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
   */

  public function handle($request, Closure $next, $role)
  {
    $user = Auth::user();

    if (!$user) {
      abort(403, 'User not logged in');
    }

    if ($user->role !== $role) {
      abort(403, "Unauthorized access. Role required: $role, but found: " . $user->role);
    }

    return $next($request);
  }
}
